export interface Issue {
    id: String;
    name: String;
    password: String;
    groupname:Array<String>;
}
