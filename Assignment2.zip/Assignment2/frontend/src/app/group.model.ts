export interface Group{
    id: String;
    groupname: String;
}
